import React from 'react';
import { TrendingUp, TrendingDown, Users, Phone, MessageSquare, Calendar } from 'lucide-react';

const Dashboard: React.FC = () => {
  const stats = [
    {
      name: 'Enquêtes envoyées',
      value: '196',
      change: '+12%',
      changeType: 'increase',
      icon: Phone,
    },
    {
      name: 'Réponses reçues',
      value: '69',
      change: '+8%',
      changeType: 'increase',
      icon: MessageSquare,
    },
    {
      name: 'Taux de réponse',
      value: '35.2%',
      change: '-2%',
      changeType: 'decrease',
      icon: TrendingUp,
    },
    {
      name: 'Contacts actifs',
      value: '1,234',
      change: '+24%',
      changeType: 'increase',
      icon: Users,
    },
  ];

  const npsData = [
    { label: 'Promoteurs', value: 75, color: 'bg-green-500' },
    { label: 'Détracteurs', value: 25, color: 'bg-red-400' },
  ];

  const sentimentData = [
    { label: 'Promoteurs 9-10', value: 75, color: 'bg-green-400' },
    { label: 'Passifs 7-8', value: 0, color: 'bg-yellow-400' },
    { label: 'Détracteurs 0-6', value: 25, color: 'bg-red-400' },
  ];

  return (
    <div className="max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Enquête de satisfaction client</h1>
            <p className="text-gray-600 mt-1">Aperçu de vos campagnes et métriques de satisfaction</p>
          </div>
          <div className="flex items-center space-x-3">
            <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-800">
              <div className="w-2 h-2 bg-green-400 rounded-full mr-2"></div>
              Public
            </span>
            <button className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors">
              Modifier l'enquête
            </button>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.name} className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.name}</p>
                  <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
                </div>
                <div className="w-12 h-12 bg-gray-50 rounded-lg flex items-center justify-center">
                  <Icon className="w-6 h-6 text-gray-600" />
                </div>
              </div>
              <div className="mt-4 flex items-center">
                {stat.changeType === 'increase' ? (
                  <TrendingUp className="w-4 h-4 text-green-500 mr-1" />
                ) : (
                  <TrendingDown className="w-4 h-4 text-red-500 mr-1" />
                )}
                <span
                  className={`text-sm font-medium ${
                    stat.changeType === 'increase' ? 'text-green-600' : 'text-red-600'
                  }`}
                >
                  {stat.change}
                </span>
                <span className="text-sm text-gray-500 ml-1">vs mois dernier</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Date Filter */}
      <div className="mb-8 flex items-center justify-between bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2">
            <Calendar className="w-5 h-5 text-gray-400" />
            <span className="text-sm font-medium text-gray-700">Plage de dates :</span>
          </div>
          <div className="flex items-center space-x-2">
            <input
              type="date"
              defaultValue="2021-01-01"
              className="border border-gray-300 rounded-lg px-3 py-2 text-sm"
            />
            <span className="text-gray-500">à</span>
            <input
              type="date"
              defaultValue="2021-09-24"
              className="border border-gray-300 rounded-lg px-3 py-2 text-sm"
            />
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-sm font-medium text-gray-700">Fréquence :</span>
            <select className="border border-gray-300 rounded-lg px-3 py-2 text-sm">
              <option>Quotidienne</option>
              <option>Hebdomadaire</option>
              <option>Mensuelle</option>
            </select>
          </div>
        </div>
        <button className="text-blue-600 hover:text-blue-700 font-medium text-sm">
          Filtrer les réponses
        </button>
      </div>

      {/* Analytics Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* NPS Score */}
        <div className="bg-white rounded-xl p-8 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900">Votre score NPS</h3>
            <div className="text-sm text-gray-500">Plage de dates : Depuis le début</div>
          </div>
          
          <div className="text-center mb-8">
            <div className="text-6xl font-bold text-gray-900 mb-2">50</div>
            <div className="text-sm text-gray-600">NPS</div>
          </div>

          <div className="space-y-4">
            {npsData.map((item, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className={`w-3 h-3 rounded-full ${item.color}`}></div>
                  <span className="text-sm font-medium text-gray-700">{item.label}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-sm font-bold text-gray-900">{item.value}%</span>
                  {index === 0 && <span className="text-xs text-gray-500">- moins</span>}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Customer Sentiment */}
        <div className="bg-white rounded-xl p-8 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900">Comment se sentent vos clients</h3>
            <div className="text-sm text-gray-500">Plage de dates : Depuis le début</div>
          </div>

          <div className="relative w-48 h-48 mx-auto mb-6">
            {/* Donut Chart */}
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                r="35"
                fill="none"
                stroke="#f3f4f6"
                strokeWidth="10"
              />
              <circle
                cx="50"
                cy="50"
                r="35"
                fill="none"
                stroke="#10b981"
                strokeWidth="10"
                strokeDasharray={`${75 * 2.2} ${25 * 2.2}`}
                strokeDashoffset="0"
                className="transition-all duration-1000"
              />
              <circle
                cx="50"
                cy="50"
                r="35"
                fill="none"
                stroke="#f87171"
                strokeWidth="10"
                strokeDasharray={`${25 * 2.2} ${75 * 2.2}`}
                strokeDashoffset={`-${75 * 2.2}`}
                className="transition-all duration-1000"
              />
            </svg>
          </div>

          <div className="space-y-3">
            {sentimentData.map((item, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className={`w-3 h-3 rounded-full ${item.color}`}></div>
                  <span className="text-sm font-medium text-gray-700">{item.label}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-sm font-bold text-gray-900">{item.value}%</span>
                  <span className="text-xs text-gray-500">({index === 0 ? '3' : index === 2 ? '1' : '0'})</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Response Summary */}
      <div className="mt-8 bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-6 text-center">
          <div>
            <div className="text-2xl font-bold text-gray-900">196</div>
            <div className="text-sm text-gray-600 uppercase tracking-wide">Envoyé</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-gray-900">196</div>
            <div className="text-sm text-gray-600 uppercase tracking-wide">Remis</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-gray-900">69</div>
            <div className="text-sm text-gray-600 uppercase tracking-wide">Ouvert</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-gray-900">4</div>
            <div className="text-sm text-gray-600 uppercase tracking-wide">Réponses</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-gray-900">1</div>
            <div className="text-sm text-gray-600 uppercase tracking-wide">Réponses avec commentaires</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;