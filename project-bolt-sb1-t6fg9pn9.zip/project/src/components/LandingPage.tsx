import React, { useState } from 'react';
import { Phone, BarChart3, Bot, Zap, Shield, Globe, ArrowRight, Check } from 'lucide-react';

interface LandingPageProps {
  onShowAuth: (mode: 'signin' | 'signup') => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onShowAuth }) => {
  const features = [
    {
      icon: Bot,
      title: 'IA Vocale Avancée',
      description: 'Notre technologie d\'IA vocale pose les questions de satisfaction de manière naturelle et conversationnelle.'
    },
    {
      icon: BarChart3,
      title: 'Analytics Puissants',
      description: 'Analysez vos données de satisfaction avec des métriques avancées comme le NPS, CSAT et CES.'
    },
    {
      icon: Zap,
      title: 'Automatisation Complète',
      description: 'Automatisez entièrement vos campagnes de satisfaction client sans intervention manuelle.'
    },
    {
      icon: Shield,
      title: 'Sécurité Maximale',
      description: 'Vos données sont protégées avec un chiffrement de niveau entreprise et une conformité RGPD.'
    },
    {
      icon: Globe,
      title: 'Multi-langues',
      description: 'Supportez plusieurs langues pour toucher tous vos clients internationaux.'
    },
    {
      icon: Phone,
      title: 'Intégration Facile',
      description: 'Intégrez facilement avec vos outils CRM existants et vos systèmes de télécommunication.'
    }
  ];

  const pricingPlans = [
    {
      name: 'Starter',
      price: '29',
      description: 'Parfait pour les petites entreprises',
      features: [
        'Jusqu\'à 500 appels/mois',
        'Templates de questions prédéfinis',
        'Dashboard basique',
        'Support email'
      ],
      popular: false
    },
    {
      name: 'Professional',
      price: '99',
      description: 'Idéal pour les entreprises en croissance',
      features: [
        'Jusqu\'à 2000 appels/mois',
        'Questions personnalisées',
        'Analytics avancés',
        'Intégrations CRM',
        'Support prioritaire'
      ],
      popular: true
    },
    {
      name: 'Enterprise',
      price: '299',
      description: 'Pour les grandes organisations',
      features: [
        'Appels illimités',
        'IA vocale personnalisée',
        'API complète',
        'Support dédié',
        'Conformité SOC2'
      ],
      popular: false
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-white/80 backdrop-blur-md z-50 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-teal-500 rounded-lg flex items-center justify-center">
                <Phone className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900">VoiceFlow</span>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <a href="#features" className="text-gray-600 hover:text-gray-900 transition-colors">Fonctionnalités</a>
              <a href="#pricing" className="text-gray-600 hover:text-gray-900 transition-colors">Tarifs</a>
              <a href="#contact" className="text-gray-600 hover:text-gray-900 transition-colors">Contact</a>
            </div>
            <div className="flex items-center space-x-4">
              <button 
                onClick={() => onShowAuth('signin')}
                className="text-gray-600 hover:text-gray-900 transition-colors"
              >
                Se connecter
              </button>
              <button 
                onClick={() => onShowAuth('signup')}
                className="bg-gradient-to-r from-blue-500 to-teal-500 text-white px-6 py-2 rounded-lg hover:shadow-lg transform hover:scale-105 transition-all duration-200"
              >
                Commencer
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-6">
        <div className="max-w-7xl mx-auto text-center">
          <div className="mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-blue-500 to-teal-500 rounded-2xl mb-6">
              <Phone className="w-8 h-8 text-white" />
            </div>
          </div>
          <h1 className="text-6xl font-bold text-gray-900 mb-6 leading-tight">
            Révolutionnez vos enquêtes de
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-teal-600"> satisfaction client</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
            Utilisez l'IA vocale pour mener des campagnes de satisfaction automatisées, 
            personnalisées et analysez les résultats en temps réel avec des tableaux de bord avancés.
          </p>
          <div className="flex justify-center space-x-4">
            <button 
              onClick={() => onShowAuth('signup')}
              className="bg-gradient-to-r from-blue-500 to-teal-500 text-white px-8 py-4 rounded-xl font-semibold hover:shadow-lg transform hover:scale-105 transition-all duration-200 flex items-center space-x-2"
            >
              <span>Commencer gratuitement</span>
              <ArrowRight className="w-5 h-5" />
            </button>
            <button className="bg-white text-gray-700 px-8 py-4 rounded-xl font-semibold border border-gray-300 hover:bg-gray-50 transition-all duration-200">
              Voir la démo
            </button>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-blue-600 mb-2">98%</div>
              <div className="text-gray-600">Taux de réponse</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-teal-600 mb-2">50%</div>
              <div className="text-gray-600">Temps économisé</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-green-600 mb-2">24/7</div>
              <div className="text-gray-600">Disponibilité</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-purple-600 mb-2">+500</div>
              <div className="text-gray-600">Entreprises clientes</div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Une plateforme complète pour vos enquêtes
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Tout ce dont vous avez besoin pour automatiser et optimiser vos campagnes de satisfaction client.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div
                  key={index}
                  className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1 border border-gray-100"
                >
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-100 to-teal-100 rounded-xl flex items-center justify-center mb-6">
                    <Icon className="w-6 h-6 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">{feature.title}</h3>
                  <p className="text-gray-600 leading-relaxed">{feature.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 px-6 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Choisissez votre plan
            </h2>
            <p className="text-xl text-gray-600">
              Des tarifs transparents qui s'adaptent à votre croissance
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {pricingPlans.map((plan, index) => (
              <div
                key={index}
                className={`bg-white rounded-2xl p-8 shadow-sm border transition-all duration-300 hover:shadow-lg ${
                  plan.popular ? 'border-blue-500 ring-2 ring-blue-100 transform scale-105' : 'border-gray-200'
                }`}
              >
                {plan.popular && (
                  <div className="bg-gradient-to-r from-blue-500 to-teal-500 text-white text-sm font-semibold px-4 py-2 rounded-full text-center mb-6">
                    Le plus populaire
                  </div>
                )}
                <div className="text-center mb-8">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">{plan.name}</h3>
                  <p className="text-gray-600 mb-4">{plan.description}</p>
                  <div className="flex items-baseline justify-center">
                    <span className="text-5xl font-bold text-gray-900">{plan.price}€</span>
                    <span className="text-gray-600 ml-2">/mois</span>
                  </div>
                </div>
                <ul className="space-y-4 mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center space-x-3">
                      <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>
                <button 
                  onClick={() => onShowAuth('signup')}
                  className={`w-full py-3 px-6 rounded-lg font-semibold transition-all duration-200 ${
                    plan.popular
                      ? 'bg-gradient-to-r from-blue-500 to-teal-500 text-white hover:shadow-lg transform hover:scale-105'
                      : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
                  }`}
                >
                  Commencer
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-6">
        <div className="max-w-4xl mx-auto">
          <div className="bg-gradient-to-r from-blue-500 to-teal-500 rounded-3xl p-16 text-center text-white">
            <h2 className="text-4xl font-bold mb-4">
              Prêt à transformer vos enquêtes de satisfaction ?
            </h2>
            <p className="text-xl mb-8 opacity-90">
              Rejoignez des centaines d'entreprises qui font confiance à VoiceFlow pour leurs campagnes de satisfaction.
            </p>
            <button 
              onClick={() => onShowAuth('signup')}
              className="bg-white text-blue-600 px-8 py-4 rounded-xl font-semibold hover:bg-gray-100 transform hover:scale-105 transition-all duration-200"
            >
              Démarrer votre essai gratuit
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-teal-500 rounded-lg flex items-center justify-center">
                  <Phone className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-bold">VoiceFlow</span>
              </div>
              <p className="text-gray-400">
                La plateforme d'enquêtes de satisfaction par IA vocale la plus avancée.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Produit</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Fonctionnalités</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Tarifs</a></li>
                <li><a href="#" className="hover:text-white transition-colors">API</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Documentation</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Contact</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Status</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Entreprise</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">À propos</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Blog</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Carrières</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 VoiceFlow. Tous droits réservés.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;