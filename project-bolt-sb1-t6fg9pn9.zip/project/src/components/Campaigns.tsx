import React, { useState } from 'react';
import { Plus, Play, Pause, MoreHorizontal, Users, Calendar, TrendingUp } from 'lucide-react';

const Campaigns: React.FC = () => {
  const [activeTab, setActiveTab] = useState('active');

  const campaigns = [
    {
      id: 1,
      name: 'Enquête de satisfaction post-achat',
      status: 'active',
      contacts: 1250,
      responses: 342,
      responseRate: 27.4,
      lastSent: '2024-01-15',
      npsScore: 68,
    },
    {
      id: 2,
      name: 'Feedback service client',
      status: 'paused',
      contacts: 890,
      responses: 156,
      responseRate: 17.5,
      lastSent: '2024-01-10',
      npsScore: 45,
    },
    {
      id: 3,
      name: 'Évaluation produit nouvelle gamme',
      status: 'draft',
      contacts: 2100,
      responses: 0,
      responseRate: 0,
      lastSent: null,
      npsScore: null,
    },
  ];

  const filteredCampaigns = campaigns.filter(campaign => {
    if (activeTab === 'active') return campaign.status === 'active';
    if (activeTab === 'paused') return campaign.status === 'paused';
    if (activeTab === 'draft') return campaign.status === 'draft';
    return true;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'paused':
        return 'bg-yellow-100 text-yellow-800';
      case 'draft':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'active':
        return 'Actif';
      case 'paused':
        return 'En pause';
      case 'draft':
        return 'Brouillon';
      default:
        return status;
    }
  };

  return (
    <div className="max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Campagnes</h1>
          <p className="text-gray-600 mt-1">Gérez vos campagnes de satisfaction Voice AI</p>
        </div>
        <button className="bg-blue-500 text-white px-6 py-3 rounded-lg hover:bg-blue-600 transition-colors flex items-center space-x-2">
          <Plus className="w-5 h-5" />
          <span>Nouvelle campagne</span>
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Campagnes actives</p>
              <p className="text-2xl font-bold text-gray-900">3</p>
            </div>
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
              <Play className="w-5 h-5 text-green-600" />
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total contacts</p>
              <p className="text-2xl font-bold text-gray-900">4,240</p>
            </div>
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <Users className="w-5 h-5 text-blue-600" />
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Taux de réponse moyen</p>
              <p className="text-2xl font-bold text-gray-900">22.3%</p>
            </div>
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-purple-600" />
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">NPS moyen</p>
              <p className="text-2xl font-bold text-gray-900">56</p>
            </div>
            <div className="w-10 h-10 bg-teal-100 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-teal-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8 px-6">
            {[
              { id: 'active', label: 'Actives', count: 1 },
              { id: 'paused', label: 'En pause', count: 1 },
              { id: 'draft', label: 'Brouillons', count: 1 },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-4 px-1 border-b-2 font-medium text-sm whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                {tab.label} ({tab.count})
              </button>
            ))}
          </nav>
        </div>

        {/* Campaigns List */}
        <div className="divide-y divide-gray-200">
          {filteredCampaigns.map((campaign) => (
            <div key={campaign.id} className="p-6 hover:bg-gray-50 transition-colors">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <h3 className="text-lg font-semibold text-gray-900">{campaign.name}</h3>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusBadge(campaign.status)}`}>
                      {getStatusText(campaign.status)}
                    </span>
                  </div>
                  
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mt-4">
                    <div>
                      <p className="text-sm text-gray-500">Contacts</p>
                      <p className="text-lg font-semibold text-gray-900">{campaign.contacts.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Réponses</p>
                      <p className="text-lg font-semibold text-gray-900">{campaign.responses}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Taux de réponse</p>
                      <p className="text-lg font-semibold text-gray-900">{campaign.responseRate}%</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Dernier envoi</p>
                      <p className="text-lg font-semibold text-gray-900">
                        {campaign.lastSent ? new Date(campaign.lastSent).toLocaleDateString('fr-FR') : '-'}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Score NPS</p>
                      <p className="text-lg font-semibold text-gray-900">{campaign.npsScore || '-'}</p>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2 ml-6">
                  {campaign.status === 'active' && (
                    <button className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg">
                      <Pause className="w-5 h-5" />
                    </button>
                  )}
                  {campaign.status === 'paused' && (
                    <button className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg">
                      <Play className="w-5 h-5" />
                    </button>
                  )}
                  <button className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg">
                    <MoreHorizontal className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Empty State */}
      {filteredCampaigns.length === 0 && (
        <div className="text-center py-12">
          <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Aucune campagne trouvée</h3>
          <p className="text-gray-500 mb-4">Créez votre première campagne pour commencer.</p>
          <button className="bg-blue-500 text-white px-6 py-2 rounded-lg hover:bg-blue-600 transition-colors">
            Créer une campagne
          </button>
        </div>
      )}
    </div>
  );
};

export default Campaigns;