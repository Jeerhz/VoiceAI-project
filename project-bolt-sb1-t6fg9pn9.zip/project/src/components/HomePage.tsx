import React from 'react';
import { Phone, BarChart3, Bot, Zap, Shield, Globe } from 'lucide-react';

const HomePage: React.FC = () => {
  const features = [
    {
      icon: Bot,
      title: 'IA Vocale Avancée',
      description: 'Notre technologie d\'IA vocale pose les questions de satisfaction de manière naturelle et conversationnelle.'
    },
    {
      icon: BarChart3,
      title: 'Analytics Puissants',
      description: 'Analysez vos données de satisfaction avec des métriques avancées comme le NPS, CSAT et CES.'
    },
    {
      icon: Zap,
      title: 'Automatisation Complète',
      description: 'Automatisez entièrement vos campagnes de satisfaction client sans intervention manuelle.'
    },
    {
      icon: Shield,
      title: 'Sécurité Maximale',
      description: 'Vos données sont protégées avec un chiffrement de niveau entreprise et une conformité RGPD.'
    },
    {
      icon: Globe,
      title: 'Multi-langues',
      description: 'Supportez plusieurs langues pour toucher tous vos clients internationaux.'
    },
    {
      icon: Phone,
      title: 'Intégration Facile',
      description: 'Intégrez facilement avec vos outils CRM existants et vos systèmes de télécommunication.'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto">
      {/* Hero Section */}
      <div className="text-center py-16">
        <div className="mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-blue-500 to-teal-500 rounded-2xl mb-6">
            <Phone className="w-8 h-8 text-white" />
          </div>
        </div>
        <h1 className="text-5xl font-bold text-gray-900 mb-6 leading-tight">
          Révolutionnez vos enquêtes de
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-teal-600"> satisfaction client</span>
        </h1>
        <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
          Utilisez l'IA vocale pour mener des campagnes de satisfaction automatisées, 
          personnalisées et analysez les résultats en temps réel avec des tableaux de bord avancés.
        </p>
        <div className="flex justify-center space-x-4">
          <button className="bg-gradient-to-r from-blue-500 to-teal-500 text-white px-8 py-4 rounded-xl font-semibold hover:shadow-lg transform hover:scale-105 transition-all duration-200">
            Commencer gratuitement
          </button>
          <button className="bg-white text-gray-700 px-8 py-4 rounded-xl font-semibold border border-gray-300 hover:bg-gray-50 transition-all duration-200">
            Voir la démo
          </button>
        </div>
      </div>

      {/* Stats Section */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-8 py-16 border-t border-gray-200">
        <div className="text-center">
          <div className="text-4xl font-bold text-blue-600 mb-2">98%</div>
          <div className="text-gray-600">Taux de réponse</div>
        </div>
        <div className="text-center">
          <div className="text-4xl font-bold text-teal-600 mb-2">50%</div>
          <div className="text-gray-600">Temps économisé</div>
        </div>
        <div className="text-center">
          <div className="text-4xl font-bold text-green-600 mb-2">24/7</div>
          <div className="text-gray-600">Disponibilité</div>
        </div>
        <div className="text-center">
          <div className="text-4xl font-bold text-purple-600 mb-2">+500</div>
          <div className="text-gray-600">Entreprises clientes</div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-16">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Une plateforme complète pour vos enquêtes
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Tout ce dont vous avez besoin pour automatiser et optimiser vos campagnes de satisfaction client.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div
                key={index}
                className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1 border border-gray-100"
              >
                <div className="w-12 h-12 bg-gradient-to-br from-blue-100 to-teal-100 rounded-xl flex items-center justify-center mb-6">
                  <Icon className="w-6 h-6 text-blue-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{feature.title}</h3>
                <p className="text-gray-600 leading-relaxed">{feature.description}</p>
              </div>
            );
          })}
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-gradient-to-r from-blue-500 to-teal-500 rounded-3xl p-16 text-center text-white">
        <h2 className="text-4xl font-bold mb-4">
          Prêt à transformer vos enquêtes de satisfaction ?
        </h2>
        <p className="text-xl mb-8 opacity-90">
          Rejoignez des centaines d'entreprises qui font confiance à VoiceFlow pour leurs campagnes de satisfaction.
        </p>
        <button className="bg-white text-blue-600 px-8 py-4 rounded-xl font-semibold hover:bg-gray-100 transform hover:scale-105 transition-all duration-200">
          Démarrer votre essai gratuit
        </button>
      </div>
    </div>
  );
};

export default HomePage;