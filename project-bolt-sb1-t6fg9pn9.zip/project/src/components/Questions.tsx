import React, { useState } from 'react';
import { Plus, Edit3, Copy, Trash2, MessageSquare, Mic } from 'lucide-react';

const Questions: React.FC = () => {
  const [selectedTemplate, setSelectedTemplate] = useState('nps');

  const questionTemplates = [
    {
      id: 'nps',
      name: 'Net Promoter Score (NPS)',
      description: 'Mesure la propension de vos clients à recommander votre entreprise',
      questions: [
        {
          id: 1,
          type: 'rating',
          question: 'Sur une échelle de 0 à 10, quelle est la probabilité que vous recommandiez notre entreprise à un ami ou collègue ?',
          scale: '0-10',
          required: true,
        },
        {
          id: 2,
          type: 'text',
          question: 'Pouvez-vous nous expliquer la raison de votre note ?',
          required: false,
        }
      ]
    },
    {
      id: 'csat',
      name: 'Customer Satisfaction (CSAT)',
      description: 'Mesure la satisfaction générale de vos clients',
      questions: [
        {
          id: 1,
          type: 'rating',
          question: 'Comment évaluez-vous votre satisfaction globale avec notre service ?',
          scale: '1-5',
          required: true,
        },
        {
          id: 2,
          type: 'multiple',
          question: 'Quel aspect de notre service vous a le plus satisfait ?',
          options: ['Qualité du produit', 'Service client', 'Rapidité de livraison', 'Prix'],
          required: false,
        }
      ]
    },
    {
      id: 'ces',
      name: 'Customer Effort Score (CES)',
      description: 'Mesure la facilité d\'interaction avec votre entreprise',
      questions: [
        {
          id: 1,
          type: 'rating',
          question: 'Dans quelle mesure était-il facile de résoudre votre problème aujourd\'hui ?',
          scale: '1-7',
          required: true,
        }
      ]
    },
    {
      id: 'custom',
      name: 'Questionnaire personnalisé',
      description: 'Créez votre propre ensemble de questions',
      questions: []
    }
  ];

  const voiceSettings = {
    language: 'fr-FR',
    voice: 'female',
    speed: 'normal',
    tone: 'friendly'
  };

  const currentTemplate = questionTemplates.find(t => t.id === selectedTemplate);

  return (
    <div className="max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Questions & Templates</h1>
          <p className="text-gray-600 mt-1">Configurez les questions de satisfaction et les paramètres Voice AI</p>
        </div>
        <button className="bg-blue-500 text-white px-6 py-3 rounded-lg hover:bg-blue-600 transition-colors flex items-center space-x-2">
          <Plus className="w-5 h-5" />
          <span>Nouveau template</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Template Selector */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Templates disponibles</h3>
            <div className="space-y-3">
              {questionTemplates.map((template) => (
                <button
                  key={template.id}
                  onClick={() => setSelectedTemplate(template.id)}
                  className={`w-full text-left p-4 rounded-lg border transition-all ${
                    selectedTemplate === template.id
                      ? 'border-blue-500 bg-blue-50 text-blue-700'
                      : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  <div className="font-medium mb-1">{template.name}</div>
                  <div className="text-sm text-gray-600">{template.description}</div>
                  <div className="text-xs text-gray-500 mt-2">
                    {template.questions.length} question{template.questions.length !== 1 ? 's' : ''}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Voice Settings */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 mt-6">
            <div className="flex items-center space-x-2 mb-4">
              <Mic className="w-5 h-5 text-blue-600" />
              <h3 className="text-lg font-semibold text-gray-900">Paramètres vocaux</h3>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Langue</label>
                <select className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
                  <option value="fr-FR">Français (France)</option>
                  <option value="en-US">English (US)</option>
                  <option value="es-ES">Español (España)</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Voix</label>
                <select className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
                  <option value="female">Féminine</option>
                  <option value="male">Masculine</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Vitesse</label>
                <select className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
                  <option value="slow">Lente</option>
                  <option value="normal">Normale</option>
                  <option value="fast">Rapide</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Ton</label>
                <select className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
                  <option value="friendly">Amical</option>
                  <option value="professional">Professionnel</option>
                  <option value="casual">Décontracté</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        {/* Question Editor */}
        <div className="lg:col-span-3">
          <div className="bg-white rounded-xl shadow-sm border border-gray-100">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-semibold text-gray-900">{currentTemplate?.name}</h2>
                  <p className="text-gray-600 mt-1">{currentTemplate?.description}</p>
                </div>
                <div className="flex space-x-2">
                  <button className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg">
                    <Copy className="w-5 h-5" />
                  </button>
                  <button className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg">
                    <Edit3 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>

            <div className="p-6">
              {currentTemplate?.questions.length === 0 ? (
                <div className="text-center py-12">
                  <MessageSquare className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">Commencez à créer vos questions</h3>
                  <p className="text-gray-500 mb-4">Ajoutez des questions personnalisées pour votre enquête de satisfaction.</p>
                  <button className="bg-blue-500 text-white px-6 py-2 rounded-lg hover:bg-blue-600 transition-colors">
                    Ajouter une question
                  </button>
                </div>
              ) : (
                <div className="space-y-6">
                  {currentTemplate?.questions.map((question, index) => (
                    <div key={question.id} className="border border-gray-200 rounded-lg p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-sm font-semibold text-blue-600">
                            {index + 1}
                          </div>
                          <div>
                            <span className="text-sm font-medium text-gray-500 uppercase tracking-wide">
                              {question.type === 'rating' ? 'Notation' : question.type === 'text' ? 'Texte libre' : 'Choix multiple'}
                            </span>
                            {question.required && (
                              <span className="ml-2 text-xs bg-red-100 text-red-800 px-2 py-1 rounded-full">
                                Obligatoire
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <button className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg">
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-100 rounded-lg">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      <div className="mb-4">
                        <p className="text-gray-900 font-medium">{question.question}</p>
                      </div>

                      {question.type === 'rating' && (
                        <div className="flex items-center space-x-2">
                          <span className="text-sm text-gray-500">Échelle :</span>
                          <span className="text-sm font-medium text-gray-900">{question.scale}</span>
                        </div>
                      )}

                      {question.type === 'multiple' && question.options && (
                        <div>
                          <p className="text-sm text-gray-500 mb-2">Options de réponse :</p>
                          <div className="space-y-2">
                            {question.options.map((option, optionIndex) => (
                              <div key={optionIndex} className="flex items-center space-x-2">
                                <div className="w-2 h-2 bg-gray-300 rounded-full"></div>
                                <span className="text-sm text-gray-700">{option}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  ))}

                  <div className="flex justify-center">
                    <button className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-medium">
                      <Plus className="w-5 h-5" />
                      <span>Ajouter une question</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Preview */}
          {currentTemplate && currentTemplate.questions.length > 0 && (
            <div className="mt-6 bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Aperçu de l'appel Voice AI</h3>
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
                    <Mic className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">Assistant VoiceFlow</p>
                    <p className="text-sm text-gray-500">Voix féminine • Français</p>
                  </div>
                </div>
                <div className="space-y-3">
                  <p className="text-gray-700">
                    <strong>Assistant :</strong> "Bonjour, je vous appelle au nom de [Nom de l'entreprise] pour une brève enquête de satisfaction. Cela ne prendra que quelques minutes de votre temps."
                  </p>
                  <p className="text-gray-700">
                    <strong>Assistant :</strong> "{currentTemplate.questions[0]?.question}"
                  </p>
                  <p className="text-gray-500 text-sm italic">
                    [L'assistant attend la réponse et pose les questions suivantes...]
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Questions;